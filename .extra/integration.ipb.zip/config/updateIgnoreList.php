<?php
/**
 * В этом файле находится массив с названиями файлов, 
 * которые не должны обновляться/удаляться при автообновлении
 *
 * пример:
 * return array(
 *  'controllers' => array(
 *   'SiteController.php',
 *  ),
 * );
 */
 
return array(
  'controllers' => array(
    'SiteController.php',
  ),
  'models' => array(
    'User.php',
  ),
  'components' => array(
    'UserIdentity.php',
    'HBeginRequest.php',
  ),
);