<?php
/**
 * HBeginRequest выполняет необходимые перед обработкой запроса действия
 * 
 * @package hamster.components.HBeginRequest
 * @version $id$
 * @copyright Copyright &copy; 2012 Sviatoslav Danylenko (http://hamstercms.com)
 * @author Sviatoslav Danylenko <mybox@udf.su> 
 * @license PGPLv3 ({@link http://www.gnu.org/licenses/gpl-3.0.html})
 */
class HBeginRequest
{
  public static function onBeginRequest($event)
  {
    if(
      Yii::app()->user->isGuest &&
      isset(Yii::app()->request->cookies['session_id']) &&
      isset(Yii::app()->request->cookies['member_id']) &&
      isset(Yii::app()->request->cookies['pass_hash'])
    )
    {
      $ipbPrefix = UserIdentity::ipbPrefix;
      $ibpSid = Yii::app()->request->cookies['session_id']->value;
      $ipbMemberId = Yii::app()->request->cookies['member_id']->value;
      $ipbPassHash = Yii::app()->request->cookies['pass_hash']->value;
      $c = Yii::app()->db->createCommand("SELECT * FROM `" . $ipbPrefix . "sessions` 
          WHERE id=:ipbSid LIMIT 1");
          
      $c->bindParam(":ipbSid",$ibpSid,PDO::PARAM_STR);
      $row = $c->queryRow();
      
      if($row && $ipbMemberId == $row['member_id'] && CHttpRequest::getUserHostAddress() == $row['ip_address'])
      {
        // Юзер залогинен в ipb. логиним его и здесь!
        $user = User::model()->findByPk($ipbMemberId);
        $user->login();
      }
    }
    
    Hi18nBehavior::onBeginRequest($event);
  }
}
