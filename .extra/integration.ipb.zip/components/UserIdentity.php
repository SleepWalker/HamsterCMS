<?php

/**
 * UserIdentity represents the data needed to identity a user.
 * It contains the authentication method that checks if the provided
 * data can identity the user.
 */
class UserIdentity extends CUserIdentity
{
  private $_id;
  
  // Папка в которой лежит ipb
  const ipbPath = 'ipb';
  // префикс таблиц в базе данных
  const ipbPrefix = 'ipb_';
  
  private $registry;
  
  /**
	 * Login handler object
	 *
	 * @var		object
	 */
	protected $han_login;
  
  public function __construct($username,$password)
  {
    parent::__construct($username,$password);
    if($_POST['LoginForm'])
    {
      $_POST['ips_password'] = $this->password;
      $_POST['ips_username'] = $this->username;
      
      
      define('IN_IPB', true);
      define( 'IPB_THIS_SCRIPT', 'public' );
      
      // обманный ход. делаем вид, что мы находимся на странице входа в ipb
      $_SERVER['REQUEST_URI'] = '/' . self::ipbPath . '/index.php?app=core&module=global&section=login';
      require_once(Yii::getPathOfAlias('webroot.' . self::ipbPath) . '/initdata.php' );/*noLibHook*/
      $classToLoad = Yii::import('webroot.' . self::ipbPath . '.admin.sources.handlers.han_login', true);
      // Turn off our amazing library autoload 
      spl_autoload_unregister(array('YiiBase','autoload')); 

      require_once( IPS_ROOT_PATH . 'sources/base/ipsRegistry.php' );/*noLibHook*/
      $this->registry = ipsRegistry::instance();
      $this->registry->init();
      
      

      $this->han_login = new $classToLoad( $this->registry );
      
      $this->han_login->init();
    }
  }
  
	/**
	 * Authenticates a user.
	 * @return boolean whether authentication succeeds.
	 */
	public function authenticate()
  {
    if(isset($this->han_login))
    {
      /* Force email check */
      $this->han_login->setForceEmailCheck( TRUE );
     
      $return = $this->han_login->verifyLogin();
      
            
      // Turn on our amazing library autoload 
      spl_autoload_register(array('YiiBase','autoload')); 
    }else{
      // это используется в том случае, когда юзер залогинен 
      // на форуме и в данный момент хомяк его логинит у себя
      $return[2] = false;
    }
    
    if( $return[2] )
    {
      // ОШИБКА ЛОГИНА
      $this->errorCode=self::ERROR_PASSWORD_INVALID;
    }
    else
    {
      // УСПЕШНЫЙ ЛОГИН
      
      $login=strtolower($this->username);
      $user=User::model()->find('LOWER(email)=?',array($login));
      
      // логиним в hamster
      $this->_id=$user->id;
      $this->setState('email', $user->email);
      $this->username= $user->first_name;

      $this->errorCode=self::ERROR_NONE;
    }
    return $this->errorCode==self::ERROR_NONE;
  }

  public function getId()
  {
      return $this->_id;
  }
}
